import FirewallAdmin from "./FirewallAdmin";

export { FirewallAdmin };

export default {
  name: "hMERN Firewall",
  version: "1.0.0",
  description: "Advanced firewall protection with admin management interface",
  components: {
    FirewallAdmin,
  },
  routes: [
    {
      path: "/admin/firewall",
      component: FirewallAdmin,
      adminOnly: true,
    },
  ],
  adminPanel: {
    enabled: true,
    menuItem: {
      title: "Firewall Management",
      description: "Manage security rules",
      icon: "Shield", // Material-UI icon name
      path: "/admin/firewall",
    },
    card: {
      title: "Firewall Protection",
      description:
        "Manage IP blocking, rate limiting, geo-blocking, and security rules. Monitor real-time threats and configure protection policies.",
      icon: "Shield",
      color: "primary.main",
      buttonText: "Manage Firewall",
      path: "/admin/firewall",
    },
  },
};
